import React from 'react';

const History = () => {
    return (
        <div>
            all histry
        </div>
    );
};

export default History;