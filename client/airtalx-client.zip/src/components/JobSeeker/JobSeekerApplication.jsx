import React from 'react';

const JobSeekerApplication = () => {
    return (
        <div>
            job
        </div>
    );
};

export default JobSeekerApplication;