import React from 'react';

const AdminSidebar = () => {
    return (
        <div>
           admin sidebar 
        </div>
    );
};

export default AdminSidebar;