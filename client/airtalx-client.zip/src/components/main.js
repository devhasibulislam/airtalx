import React from "react";
import Home from "./Home";
import Footer from "./foot";
// import Footer from './Footer';

const Main = () => {
  return (
    <div>
      <Home />
      <Footer />
    </div>
  );
};

export default Main;
